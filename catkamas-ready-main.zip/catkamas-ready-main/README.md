# catkamas-ready
aplikasi yang mencatat riwayat suatu kambing dalam masa pemeliharaan serta kode pada setiap kambing yang dipelihara sehingga menjadi sebuah catatan bagii calon peternak lainya.
